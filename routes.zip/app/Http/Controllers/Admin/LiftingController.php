<?php

namespace App\Http\Controllers\Admin;

use ZipArchive;
use Carbon\Carbon;
use App\Models\Store;
use App\Models\Vendor;
use App\Models\Company;
use App\Models\Lifting;
use App\Models\Product;
use App\Models\CoaSetup;
use App\Models\AccessLog;
use App\Models\AdminSetting;
use Illuminate\Http\Request;
use App\Models\VendorPayment;
use App\Models\LiftingProduct;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\LiftingDocument;
use App\Models\LiftingReturnList;
use App\Models\VendorPaymentData;
use Illuminate\Support\Facades\DB;
use App\Models\AccountTransaction;
use App\Models\Scopes\CompanyScope;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\AccountTransactionAuto;
use Yajra\DataTables\Facades\DataTables;
use App\Services\ActionButtons\ActionButtons;

class LiftingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (request()->ajax()) {
            $model = Lifting::with(['company', 'store', 'staff', 'vendor'])->latest('id')->where('product_type', 'Consumer');
            $type = request('type');
            if (!empty($type) && $type == 'trash') {
                $model->onlyTrashed();
            }
            return DataTables::eloquent($model)
                ->addColumn('checkbox', function ($row) {
                    $payemnt = VendorPaymentData::where('lifting_id', $row->id)->whereHas('payment')->first();
                    $transaction = AccountTransaction::withTrashed()->where('voucher_no', $row->lifting_no)->where('voucher_type', 'Product Purchase')->first();
                    $pay_transaction = AccountTransaction::withTrashed()->where('voucher_no', @$payemnt->payment->payment_no)->where('voucher_type', 'Vendor Payment')->first();
                    if (is_null($payemnt) && is_null($transaction) && is_null($pay_transaction)) {
                        $checkbox = '<div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input ' . (!empty(request('type')) && request('type') == "trash" ? 'trash_multi_checkbox' : 'multi_checkbox') . '" id="' . $row->id . '" name="multi_checkbox[]" value="' . $row->id . '"><label for="' . $row->id . '" class="custom-control-label"></label></div>';
                        return $checkbox;
                    }
                })
                ->addColumn('lifting_date', function ($row) {
                    return date('d-m-Y', strtotime($row->lifting_date));
                })
                ->addColumn('actions', function ($row) {
                    $type = request('type');
                    $data = [
                        'id' => $row->id,
                        'edit' => !empty($type) && $type == 'trash' ? false : true,
                    ];
                    $actionBtn = '<a class="btn btn-sm border-0 px-10px fs-15 btn-info tt" href="' . Route('admin.lifting.show', $row->id) . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Print Voucher" target="_blank"><i class="fal fa-print"></i></a>';

                    $payemnt = VendorPaymentData::where('lifting_id', $row->id)->whereHas('payment')->first();
                    $transaction = AccountTransaction::withTrashed()->where('voucher_no', $row->lifting_no)->where('voucher_type', 'Product Purchase')->first();
                    if (is_null($payemnt) && is_null($transaction) || !is_null($payemnt) && $row->payment_type == 'cash' && is_null($transaction)) {
                        return ActionButtons::actions($data, $actionBtn);
                    }
                    return '<div class="btn-group">' . $actionBtn . '</div>';
                })
                ->rawColumns(['checkbox', 'actions'])
                ->make(true);
        }

        $title = "Product Lifting";
        return view('admin.lifting.index', compact('title'));
    }

    public function receivedList(Request $request)
    {
        $title = "received";
        $filter_link = Route('admin.received.list');

        $date_range = explode('to', $request->date_range);
        $start_date = isset($date_range[0]) ? date('Y-m-d', strtotime(trim($date_range[0]))) : null;
        $end_date   = isset($date_range[1]) ? date('Y-m-d', strtotime(trim($date_range[1]))) : null;

        $vendor_id = $request->vendor_id;

        $vendors = Vendor::where('status', 1)
            ->orderBy('name', 'asc')
            ->get();

        $query = DB::table('vendors as v')
            ->leftJoin('lifting_products as lp', 'v.id', '=', 'lp.vendor_id')
            ->select(
                'v.id',
                'v.name',
                DB::raw('MAX(lp.created_at) as sale_date'),
                DB::raw('SUM(lp.qty) as total_qty'),
                DB::raw('SUM(lp.delivery) as total_delivery')
            );

        if (!empty($request->vendor_id)) {
            $query->where('v.id', $request->vendor_id);
        }

        if (!empty($start_date) && !empty($end_date)) {
            $query->whereBetween(DB::raw('DATE(lp.created_at)'), [$start_date, $end_date]);
        }

        $data = $query
            ->groupBy('v.id', 'v.name')
            ->orderBy('v.name')
            ->get();

        // Grand Total
        $grand_total_qty = $data->sum('total_qty');
        $grand_total_delivery = $data->sum('total_delivery');

        return view(
            'admin.received.receivedList',
            compact(
                'title',
                'filter_link',
                'vendors',
                'data',
                'start_date',
                'end_date',
                'vendor_id',
                'grand_total_qty',
                'grand_total_delivery'
            )
        );
    }

    public function receivePendingList(Request $request)
    {
        $title = "receive Pending";
        $filter_link = Route('admin.receive.pending.list');

        $date_range = explode('to', $request->date_range);
        $start_date = isset($date_range[0]) ? date('Y-m-d', strtotime(trim($date_range[0]))) : null;
        $end_date   = isset($date_range[1]) ? date('Y-m-d', strtotime(trim($date_range[1]))) : null;

        $vendor_id = $request->vendor_id;

        $vendors = Vendor::where('status', 1)
            ->orderBy('name', 'asc')
            ->get();

        $query = DB::table('vendors as v')
            ->leftJoin('lifting_products as lp', 'v.id', '=', 'lp.vendor_id')
            ->select(
                'v.id',
                'v.name',
                DB::raw('MAX(lp.created_at) as sale_date'),
                DB::raw('SUM(lp.qty) as total_qty'),
                DB::raw('SUM(lp.delivery) as total_delivery')
            );

        if (!empty($request->vendor_id)) {
            $query->where('v.id', $request->vendor_id);
        }

        if (!empty($start_date) && !empty($end_date)) {
            $query->whereBetween(DB::raw('DATE(lp.created_at)'), [$start_date, $end_date]);
        }

        $data = $query
            ->groupBy('v.id', 'v.name')
            ->orderBy('v.name')
            ->get();

        // Grand Total
        $grand_total_qty = $data->sum('total_qty');
        $grand_total_delivery = $data->sum('total_delivery');

        return view(
            'admin.received.receivePendingList',
            compact(
                'title',
                'filter_link',
                'vendors',
                'data',
                'start_date',
                'end_date',
                'vendor_id',
                'grand_total_qty',
                'grand_total_delivery'
            )
        );
    }


    public function receiveEdit(string $vendorid)
    {
        $vendor = DB::table('vendors')
            ->where('id', $vendorid)
            ->first();

        if (!$vendor) {
            return redirect()->back()->with('error', 'Vendor not found.');
        }

        // Vendor wise Purchase
        $purchases = DB::table('liftings as l')
            ->leftJoin('vendors as v', 'v.id', '=', 'l.vendor_id')
            ->where('l.vendor_id', $vendorid)
            ->select(
                'l.id',
                'l.lifting_no',
                'l.lifting_date',
                'l.vendor_id',
                'v.name as vendor_name'
            )
            ->orderBy('l.lifting_date', 'desc')
            ->get();

        // Vendor wise Receives
        $receives = DB::table('lifting_products as lp')
            ->leftJoin('products as p', 'p.id', '=', 'lp.product_id')
            ->leftJoin('liftings as l', 'l.id', '=', 'lp.lifting_id')
            ->where('lp.vendor_id', $vendorid)
            ->whereColumn('lp.delivery', '<>', 'lp.qty')
            ->select(
                'lp.*',
                'l.lifting_no',
                'l.lifting_date as purchase_date',
                'p.name as product_name',
                'p.code as product_code',
                'p.id as product_id'
            )
            ->orderBy('l.lifting_date', 'desc')
            ->get()
            ->groupBy('lifting_id');

        return view('admin.received.receive_edit', compact(
            'vendor',
            'purchases',
            'receives'
        ));
    }

    public function receiveUpdate(Request $request, string $vendorid)
    {
        DB::beginTransaction();

        try {

            $total_delivery_amount = 0;

            foreach ($request->delivery_id ?? [] as $key => $deliveryId) {

                $product = Product::find($request->product_id[$key] ?? null);

                if (!$product) {
                    continue;
                }

                $qty = (float) ($request->qty[$key] ?? 0);
                $deliveryQty = (float) ($request->delivery_qty[$key] ?? 0);
                $rate = (float) ($product->price->lifting_price ?? 0);

                /*
                |--------------------------------------------------------------------------
                | Delivery Validation
                |--------------------------------------------------------------------------
                */

                if ($deliveryQty > $qty) {
                    throw new \Exception(
                        'Delivery quantity cannot be greater than quantity.'
                    );
                }

                /*
                |--------------------------------------------------------------------------
                | Trade Discount
                |--------------------------------------------------------------------------
                */

                $tradediscount = 0;
                

                if ($product->type == 1) {

                    $doRatio = (int) $product->do_ratio;

                    if ($doRatio > 0) {

                        $freeqty = floor($qty / $doRatio);

                        $offerqty = $qty - $freeqty;

                        $offerSubtotal = $offerqty * $rate;

                        $tradediscount = $freeqty * $rate;
                    }
                }

                /*
                |--------------------------------------------------------------------------
                | Delivery Amount
                |--------------------------------------------------------------------------
                */

                $deliveryAmount = $deliveryQty * $rate;

                $total_delivery_amount += $deliveryAmount;


                /*
                |--------------------------------------------------------------------------
                | Update Sales List
                |--------------------------------------------------------------------------
                */
                DB::table('lifting_products')
                    ->where('id', $deliveryId)
                    ->where('vendor_id', $vendorid)
                    ->update([
                        'delivery'        => $deliveryQty,
                        'delivery_amount' => $deliveryAmount,
                        'discount'        => $tradediscount,
                        'updated_at'      => now(),
                    ]);
            }


            DB::commit();

            return redirect()
                ->route('admin.received.list')
                ->withSuccessMessage(
                    'Vendor Receive updated successfully.'
                );

        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()
                ->back()
                ->withInput()
                ->with('error', $e->getMessage());
        }
    }


    public function receivePrint(string $vendorid)
    {
        /*
        |--------------------------------------------------------------------------
        | Vendor-এর সব Invoice / Sales
        |--------------------------------------------------------------------------
        */

        $liftings = Lifting::where('vendor_id', $vendorid)
            ->orderBy('id', 'desc')
            ->get();

        if ($liftings->isEmpty()) {
            abort(404, 'No sales found for this vendor.');
        }


        /*
        |--------------------------------------------------------------------------
        | Vendor
        |--------------------------------------------------------------------------
        */

        $vendor = $liftings->first()->vendor;

        if (!$vendor) {
            abort(404, 'Vendor not found.');
        }


        /*
        |--------------------------------------------------------------------------
        | Vendor / Company Information
        |--------------------------------------------------------------------------
        */

        $company = $vendor->name;
        $hotline = $vendor->phone;
        $logo = $vendor->logo;
        $title = $vendor->name;

        $informations =
            $vendor->address . '</br>' .
            $vendor->phone . ', ' .
            $vendor->email . ', ' .
            $vendor->contact_person;


        /*
        |--------------------------------------------------------------------------
        | Vendor-এর সব Sales List
        |--------------------------------------------------------------------------
        */

        $lists = LiftingProduct::with('product')
            ->where('vendor_id', $vendorid)
            ->where('delivery', '>', 0)
            ->orderBy('id', 'asc')
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Vendor-wise Delivery Amount
        |--------------------------------------------------------------------------
        */

        $vendor_total_delivery_amount = LiftingProduct::where('vendor_id', $vendorid)
            ->sum('delivery_amount');


        /*
        |--------------------------------------------------------------------------
        | Vendor-wise Discount
        |--------------------------------------------------------------------------
        */

        $total_discount_amount = LiftingProduct::where('vendor_id', $vendorid)
            ->sum('discount');


        /*
        |--------------------------------------------------------------------------
        | Vendor-এর Total Sales Amount
        |--------------------------------------------------------------------------
        */

        $vendor_total_amount = LiftingProduct::where('vendor_id', $vendorid)
            ->sum('delivery_amount');


        /*
        |--------------------------------------------------------------------------
        | Total Paid Amount
        |--------------------------------------------------------------------------
        */

        $total_paid_amount = VendorPayment::where('vendor_id', $vendorid)
            ->sum('amount');


        /*
        |--------------------------------------------------------------------------
        | Opening / Outstanding Balance
        |--------------------------------------------------------------------------
        */

        $opening = $vendor_total_delivery_amount
            - $total_discount_amount
            - $total_paid_amount;


        /*
        |--------------------------------------------------------------------------
        | Latest / Main Data Object
        |--------------------------------------------------------------------------
        */

        $data = $liftings->first();

        $data->list = $lists;

        $data->vendor = $vendor;


        /*
        |--------------------------------------------------------------------------
        | Vendor-wise Total Delivery Amount
        |--------------------------------------------------------------------------
        */

        $data->total_delivery_amount =
            $vendor_total_delivery_amount;


        /*
        |--------------------------------------------------------------------------
        | Vendor-wise Total Quantity
        |--------------------------------------------------------------------------
        */

        $data->total_qty = LiftingProduct::where('vendor_id', $vendorid)
            ->sum('qty');


        /*
        |--------------------------------------------------------------------------
        | Vendor-wise Total Delivered Quantity
        |--------------------------------------------------------------------------
        */

        $data->total_delivery_qty = LiftingProduct::where('vendor_id', $vendorid)
            ->sum('delivery');


        /*
        |--------------------------------------------------------------------------
        | Vendor-wise Pending Quantity
        |--------------------------------------------------------------------------
        */

        $data->total_pending_qty =
            $data->total_qty -
            $data->total_delivery_qty;


        /*
        |--------------------------------------------------------------------------
        | Report Information
        |--------------------------------------------------------------------------
        */

        $data->invoice = 'VENDOR-WISE DELIVERY HISTORY';

        $data->date = $liftings->max('lifting_date');

        $data->updated_at = $liftings->max('updated_at');


        /*
        |--------------------------------------------------------------------------
        | Report Title
        |--------------------------------------------------------------------------
        */

        $report_title = 'Received';


        /*
        |--------------------------------------------------------------------------
        | Return View
        |--------------------------------------------------------------------------
        */

        return view(
            'admin.received.receivePrint',
            compact(
                'title',
                'total_discount_amount',
                'logo',
                'informations',
                'hotline',
                'report_title',
                'data',
                'opening',
                'vendor_total_delivery_amount'
            )
        );
    }

    public function invoice()
    {
        $first = date('Y-m-01');
        $last = new Carbon('last day of this month');
        $data = Lifting::withoutGlobalScope(CompanyScope::class)->withTrashed()->select(['lifting_no'])->whereDate('created_at', '>=', $first)->whereDate('created_at', '<=', $last)->latest('id')->first();
        if ($data) {
            $trim = str_replace("STL", '', $data->lifting_no);
            $dataPrefix = (int)$trim + 1;
            $invoice = "STL" . $dataPrefix;
        } else {
            $invoice = "STL" . date('y') . date('m') . '000001';
        }
        return $invoice;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (request()->ajax() && request('get_product')) {
            $product = Product::with(['price', 'category'])->where('id', request('product_id'))->first();
            return response()->json(['status' => 'success', 'product' => $product]);
        }

        if (request()->ajax()) {
            $products = Product::whereHas('vendors', function ($q) {
                $q->where('vendor_id', request('vendor_id'));
            })->where('status', 1)->orderBy('name', 'asc')->get();
            return response()->json(['status' => 'success', 'products' => $products]);
        }

        $title = 'Add Product Lifting';
        $lifting_no = $this->invoice();
        $vendors = Vendor::where('status', 1)->orderBy('name', 'asc')->get();
        $stores = Store::where('status', 1)->get();
        $cash_heads = CoaSetup::with('parent')->whereHas('parent', function ($query) {
            $query->where('head_name', 'Cash In Hand')->orWhere('head_name', 'Cash In Bank');
        })->get();
        return view('admin.lifting.create', compact('title', 'lifting_no', 'vendors', 'stores', 'cash_heads'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'lifting_no' => 'required',
            'lifting_date' => 'required',
            'vendor_id' => 'required',
            'product_id' => 'required',
            'lifting_price' => 'required',
            'quantity' => 'required',
        ]);

        $admin_setting = AdminSetting::first();
        if (@$admin_setting->accounting == 1 && $request->payment_type == 'cash') {
            $request->validate([
                'coa_setup_id' => 'required',
            ]);
        }

        $vendor = Vendor::find($request->vendor_id);
        if (@$admin_setting->accounting == 1 && is_null($vendor->coa)) {
            return redirect()->back()->withErrors('Please Setup a vendors account!');
        }

        DB::transaction(function () use ($request, $admin_setting) {
            $lifting_no = $this->invoice();
            $lifting = Lifting::create([
                'company_id' => Auth::user()->company_id ?? 1,
                'store_id' => $request->store_id,
                'vendor_id' => $request->vendor_id,
                'coa_setup_id' => $request->coa_setup_id,
                'lifting_no' => $lifting_no,
                'voucher_no' => $request->voucher_no,
                'payment_type' => $request->payment_type,
                'lifting_date' => date('Y-m-d', strtotime($request->lifting_date)),
                'total_cost' => $request->total_cost ?? 0,
                'discount' => $request->discount ?? 0,
                'net_amount' => ($request->total_cost ?? 0) - ($request->discount ?? 0),
                'total_paid' => $request->payment_type == 'cash' ? $request->net_payable : 0.00,
                'created_by' => Auth::user()->id,
            ]);

            $log_data = '';
            foreach ($request->product_id as $key => $product_id) {
                $product = Product::where('id', $product_id)->first();
                $discount = ($request->discount / $request->total_cost) * $request->amount[$key];
                if ($request->payment_type == 'cash') {
                    $total_paid = $request->amount[$key] - $discount;
                } else {
                    $total_paid = 0;
                }
                LiftingProduct::create([
                    'lifting_id' => $lifting->id,
                    'company_id' => Auth::user()->company_id ?? 1,
                    'store_id' => $request->store_id,
                    'vendor_id' => $request->vendor_id,
                    'product_id' => $product_id,
                    'total_amount' => $request->amount[$key],
                    'total_paid' => $total_paid,
                    'lifting_price' => $request->lifting_price[$key],
                    'discount' => $discount,
                    'net_amount' => $request->amount[$key] - $discount,
                    'expiry_date' => !is_null(@$request->expiry_date[$key]) ? date('Y-m-d', strtotime(@$request->expiry_date[$key])) : null,
                    'qty' => $request->quantity[$key],
                    'created_by' => Auth::user()->id,
                ]);
                $log_data .= ' ' . $product->name . ' ' . $request->quantity[$key] . ' ' . $product->attribute->name . ' ';
            }

            $vendor = Vendor::find($request->vendor_id);
            if ($vendor->coa && @$admin_setting->accounting == 1) {
                $expense_head = CoaSetup::where('head_type', 'E')->where('head_name', 'Product Purchase')->first();
                $headCode = collect([
                    '0' => $expense_head->head_code,
                    '1' => $vendor->coa->head_code
                ]);

                $debit_amount = collect([
                    '0' => $request->net_payable,
                    '1' => 0.00
                ]);

                $credit_amount = collect([
                    '0' => 0.00,
                    '1' => $request->net_payable,
                ]);

                $countHead = count($headCode);
                $postData = [];
                for ($i = 0; $i < $countHead; $i++) {
                    $coa = CoaSetup::where('company_id', Auth::user()->company_id ?? 1)->where('head_code', $headCode[$i])->first();
                    $postData[] = [
                        'company_id' => Auth::user()->company_id ?? 1,
                        'voucher_no' => $lifting->lifting_no,
                        'voucher_type' => "Product Purchase",
                        'voucher_date' => date('Y-m-d', strtotime($request->lifting_date)),
                        'coa_setup_id' => $coa->id,
                        'coa_head_code' => $headCode[$i],
                        'narration' => 'Product Purchase Against Purchase No - ' . $lifting->lifting_no,
                        'debit_amount' => $debit_amount[$i],
                        'credit_amount' => $credit_amount[$i],
                        'created_by' => Auth::user()->id,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now()
                    ];
                }
                AccountTransactionAuto::insert($postData);
            }

            if ($request->payment_type == 'cash') {
                $first = date('Y-m-01');
                $last = new Carbon('last day of this month');
                $pay_data = VendorPayment::withoutGlobalScope(CompanyScope::class)->withTrashed()->select(['payment_no'])->whereDate('created_at', '>=', $first)->whereDate('created_at', '<=', $last)->orderBy('id', 'desc')->first();
                if ($pay_data) {
                    $trim = str_replace("STP", '', $pay_data->payment_no);
                    $dataPrefix = (int)$trim + 1;
                    $payment_no = "STP" . $dataPrefix;
                } else {
                    $payment_no = "STP" . date('y') . date('m') . '000001';
                }

                $vendor_payment = VendorPayment::create([
                    'company_id' => Auth::user()->company_id ?? 1,
                    'vendor_id' => $request->vendor_id,
                    'lifting_id' => $lifting->id,
                    'payment_no' => $payment_no,
                    'payment_date' => date('Y-m-d', strtotime($request->lifting_date)),
                    'payment_type' => $request->payment_type,
                    'type' => 'payment',
                    'amount' => $request->total_cost - $request->discount,
                    'remarks' => 'Cash Purchase',
                    'created_by' => Auth::user()->id,
                ]);

                VendorPaymentData::create([
                    'vendor_payment_id' => $vendor_payment->id,
                    'lifting_id' => $lifting->id,
                    'paid' => $request->total_cost - $request->discount,
                ]);

                if ($vendor->coa && @$admin_setting->accounting == 1) {
                    $cash_head = CoaSetup::findOrFail($request->coa_setup_id);
                    $headCode = collect([
                        '0' => $vendor->coa->head_code,
                        '1' => $cash_head->head_code,
                    ]);

                    $postData = [];
                    for ($i = 0; $i < $countHead; $i++) {
                        $coa = CoaSetup::where('company_id', Auth::user()->company_id ?? 1)->where('head_code', $headCode[$i])->first();
                        $postData[] = [
                            'company_id' => Auth::user()->company_id ?? 1,
                            'voucher_no' => $payment_no,
                            'voucher_type' => "Vendor Payment",
                            'voucher_date' => date('Y-m-d', strtotime($request->lifting_date)),
                            'coa_setup_id' => $coa->id,
                            'coa_head_code' => $headCode[$i],
                            'narration' => 'Payment Vendor Against PAYMENT NO - ' . $payment_no,
                            'debit_amount' => $debit_amount[$i],
                            'credit_amount' => $credit_amount[$i],
                            'created_by' => Auth::user()->id,
                            'created_at' => Carbon::now(),
                            'updated_at' => Carbon::now()
                        ];
                    }
                    AccountTransactionAuto::insert($postData);
                }
            }

            $store = Store::findOrFail($request->store_id);
            AccessLog::create([
                'date_time' => Carbon::now(),
                'page' => 'Purchase',
                'action' => 'Add',
                'description' => 'Create a new purhcase with purchase no ' . $lifting->lifting_no . ' to ' . $store->name . ' products ' . $log_data . ' on ' . $request->payment_type,
                'user_id' => Auth::user()->id,
            ]);
        });

        return redirect()->route('admin.lifting.index')->withSuccessMessage('Created Successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Request $request, string $id)
    {
       $data = Lifting::findOrFail($id);
      
        if ( $data) {
            $company = $data->vendor->name;
            $hotline = $data->vendor->phone;
            $logo = $data->vendor->logo;
            $title = $data->vendor->name;
            $informations = $data->vendor->address . '</br>' . $data->vendor->phone . ', ' . $data->vendor->email . ', ' . $data->vendor->contact_person;
        } else {
            $logo = NULL;
            $hotline = '01xxxxx-xxxxx';
            $title = 'Company Name Goes Here.';
            $informations = 'Company address will goes here </br> Mobile: 0967XXXXXX, Email: youremail@gmail.com, www.website.com';
        }
        $report_title = 'Lifting Voucher';
         return view('admin.lifting.print', compact('title', 'informations', 'report_title', 'data','logo'));
        //$pdf = Pdf::loadView('admin.lifting.print', compact('title', 'informations', 'report_title', 'data'));
        // $pdf->setPaper('A4', 'landscape');
        return $pdf->stream('product_lifting_chalan_' . date('d_m_Y_H_i_s') . '.pdf');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (request()->ajax() && request('get_product')) {
            $product = Product::with(['price', 'category'])->where('id', request('product_id'))->first();
            return response()->json(['status' => 'success', 'product' => $product]);
        }

        if (request()->ajax()) {
            $products = Product::whereHas('vendors', function ($q) {
                $q->where('vendor_id', request('vendor_id'));
            })->where('status', 1)->orderBy('name', 'asc')->get();
            return response()->json(['status' => 'success', 'products' => $products]);
        }

        $title = 'Update Lifting Products';
        $vendors = Vendor::where('status', 1)->orderBy('name', 'asc')->get();
        $stores = Store::where('status', 1)->get();
        $data = Lifting::findOrFail($id);
        $lifting_products = LiftingProduct::with(['product'])->where('lifting_id', $id)->get();
        $link = Route('admin.lifting.update', $id);
        $products = Product::whereHas('vendors', function ($q) use ($data) {
            $q->where('vendor_id', $data->vendor_id);
        })->orderBy('name', 'asc')->get();
        $cash_heads = CoaSetup::with('parent')->whereHas('parent', function ($query) {
            $query->where('head_name', 'Cash In Hand')->orWhere('head_name', 'Cash In Bank');
        })->get();
        return view('admin.lifting.edit', compact('title', 'vendors', 'stores', 'data', 'lifting_products', 'link', 'products', 'cash_heads'));
    }

    public function showDocument(string $id)
    {
        $lifting_documents =  LiftingDocument::where('lifting_id', $id)->get();
        $zip = new ZipArchive();
        $fileName = 'downloads.zip';
        // Add File in ZipArchive
        if ($zip->open(public_path($fileName), ZipArchive::CREATE) === TRUE) {
            foreach ($lifting_documents as $file) {
                $path =  public_path($file->document);
                $relativeName = basename($path);
                $zip->addFile($path, $relativeName);
            }
        }
        // Close ZipArchive
        $zip->close();
        return response()->download($fileName);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'lifting_no' => 'required',
            'lifting_date' => 'required',
            'vendor_id' => 'required',
            'product_id' => 'required',
            'lifting_price' => 'required',
            'quantity' => 'required',
        ]);

        $admin_setting = AdminSetting::first();
        if (@$admin_setting->accounting == 1 && $request->payment_type == 'cash') {
            $request->validate([
                'coa_setup_id' => 'required',
            ]);
        }

        $vendor = Vendor::find($request->vendor_id);
        if (@$admin_setting->accounting == 1 && is_null($vendor->coa)) {
            return redirect()->back()->withErrors('Please Setup a vendors account!');
        }

        DB::transaction(function () use ($request, $id, $admin_setting) {

            $lifting = Lifting::findOrFail($id);
            $payment = VendorPayment::withTrashed()->where('lifting_id', $id)->first();
            AccountTransactionAuto::withTrashed()->where('voucher_no', $lifting->lifting_no)->where('voucher_type', 'Product Purchase')->forceDelete();
            if ($payment) {
                AccountTransactionAuto::withTrashed()->where('voucher_no', $payment->payment_no)->where('voucher_type', 'Vendor Payment')->forceDelete();
                $payment->forceDelete();
            }
            foreach ($lifting->products as $item) {
                LiftingReturnList::where('lifting_product_id', $item->id)->forceDelete();
            }
            LiftingProduct::where('lifting_id', $id)->delete();

            $lifting->update([
                'store_id' => $request->store_id,
                'vendor_id' => $request->vendor_id,
                'coa_setup_id' => $request->coa_setup_id,
                'voucher_no' => $request->voucher_no,
                'payment_type' => $request->payment_type,
                'lifting_date' => date('Y-m-d', strtotime($request->lifting_date)),
                'total_cost' => $request->total_cost ?? 0,
                'discount' => $request->discount ?? 0,
                'net_amount' => ($request->total_cost ?? 0) - ($request->discount ?? 0),
                'total_paid' => $request->payment_type == 'cash' ? $request->net_payable : 0.00,
                'updated_by' => Auth::user()->id,
            ]);

            $log_data = '';
            foreach ($request->product_id as $key => $product_id) {
                $product = Product::where('id', $product_id)->first();
                $discount = ($request->discount / $request->total_cost) * $request->amount[$key];
                if ($request->payment_type == 'cash') {
                    $total_paid = $request->amount[$key] - $discount;
                } else {
                    $total_paid = 0;
                }
                LiftingProduct::create([
                    'lifting_id' => $lifting->id,
                    'company_id' => Auth::user()->company_id ?? 1,
                    'store_id' => $request->store_id,
                    'vendor_id' => $request->vendor_id,
                    'product_id' => $product_id,
                    'total_amount' => $request->amount[$key],
                    'total_paid' => $total_paid,
                    'lifting_price' => $request->lifting_price[$key],
                    'discount' => $discount,
                    'net_amount' => $request->amount[$key] - $discount,
                    'expiry_date' => !is_null(@$request->expiry_date[$key]) ? date('Y-m-d', strtotime(@$request->expiry_date[$key])) : null,
                    'qty' => $request->quantity[$key],
                    'delivery' => $request->delivery[$key],
                    'created_by' => Auth::user()->id,
                ]);
                $log_data .= ' ' . $product->name . ' ' . $request->quantity[$key] . ' ' . $product->attribute->name . ' ';
            }

            $vendor = Vendor::find($request->vendor_id);
            if ($vendor->coa && @$admin_setting->accounting == 1) {
                $expense_head = CoaSetup::where('head_type', 'E')->where('head_name', 'Product Purchase')->first();
                $headCode = collect([
                    '0' => $expense_head->head_code,
                    '1' => $vendor->coa->head_code
                ]);

                $debit_amount = collect([
                    '0' => $request->net_payable,
                    '1' => 0.00
                ]);

                $credit_amount = collect([
                    '0' => 0.00,
                    '1' => $request->net_payable,
                ]);

                $countHead = count($headCode);
                $postData = [];
                for ($i = 0; $i < $countHead; $i++) {
                    $coa = CoaSetup::where('company_id', Auth::user()->company_id ?? 1)->where('head_code', $headCode[$i])->first();
                    $postData[] = [
                        'company_id' => Auth::user()->company_id ?? 1,
                        'voucher_no' => $lifting->lifting_no,
                        'voucher_type' => "Product Purchase",
                        'voucher_date' => date('Y-m-d', strtotime($request->lifting_date)),
                        'coa_setup_id' => $coa->id,
                        'coa_head_code' => $headCode[$i],
                        'narration' => 'Product Purchase Against Purchase No - ' . $lifting->lifting_no,
                        'debit_amount' => $debit_amount[$i],
                        'credit_amount' => $credit_amount[$i],
                        'created_by' => Auth::user()->id,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now()
                    ];
                }
                AccountTransactionAuto::insert($postData);
            }

            if ($request->payment_type == 'cash') {
                $first = date('Y-m-01');
                $last = new Carbon('last day of this month');
                $pay_data = VendorPayment::withoutGlobalScope(CompanyScope::class)->withTrashed()->select(['payment_no'])->whereDate('created_at', '>=', $first)->whereDate('created_at', '<=', $last)->orderBy('id', 'desc')->first();
                if ($pay_data) {
                    $trim = str_replace("STP", '', $pay_data->payment_no);
                    $dataPrefix = (int)$trim + 1;
                    $payment_no = "STP" . $dataPrefix;
                } else {
                    $payment_no = "STP" . date('y') . date('m') . '000001';
                }

                $vendor_payment = VendorPayment::create([
                    'company_id' => Auth::user()->company_id ?? 1,
                    'vendor_id' => $request->vendor_id,
                    'lifting_id' => $lifting->id,
                    'payment_no' => $payment_no,
                    'payment_date' => date('Y-m-d', strtotime($request->lifting_date)),
                    'payment_type' => $request->payment_type,
                    'type' => 'payment',
                    'amount' => $request->total_cost - $request->discount,
                    'remarks' => 'Cash Purchase',
                    'created_by' => Auth::user()->id,
                ]);

                VendorPaymentData::create([
                    'vendor_payment_id' => $vendor_payment->id,
                    'lifting_id' => $lifting->id,
                    'paid' => $request->total_cost - $request->discount,
                ]);

                if ($vendor->coa && @$admin_setting->accounting == 1) {
                    $cash_head = CoaSetup::findOrFail($request->coa_setup_id);
                    $headCode = collect([
                        '0' => $vendor->coa->head_code,
                        '1' => $cash_head->head_code,
                    ]);

                    $postData = [];
                    for ($i = 0; $i < $countHead; $i++) {
                        $coa = CoaSetup::where('company_id', Auth::user()->company_id ?? 1)->where('head_code', $headCode[$i])->first();
                        $postData[] = [
                            'company_id' => Auth::user()->company_id ?? 1,
                            'voucher_no' => $payment_no,
                            'voucher_type' => "Vendor Payment",
                            'voucher_date' => date('Y-m-d', strtotime($request->lifting_date)),
                            'coa_setup_id' => $coa->id,
                            'coa_head_code' => $headCode[$i],
                            'narration' => 'Payment Vendor Against PAYMENT NO - ' . $payment_no,
                            'debit_amount' => $debit_amount[$i],
                            'credit_amount' => $credit_amount[$i],
                            'created_by' => Auth::user()->id,
                            'created_at' => Carbon::now(),
                            'updated_at' => Carbon::now()
                        ];
                    }
                    AccountTransactionAuto::insert($postData);
                }
            }

            $store = Store::findOrFail($request->store_id);
            AccessLog::create([
                'date_time' => Carbon::now(),
                'page' => 'Purchase',
                'action' => 'Update',
                'description' => 'Update purhcase against purchase no ' . $lifting->lifting_no . ' to ' . $store->name . ' products : ' . $log_data . ' on ' . $request->payment_type,
                'user_id' => Auth::user()->id,
            ]);
        });
        return redirect()->route('admin.lifting.index')->withSuccessMessage('Updated Successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // Recovery Deleted Data
        if (request()->has('recovery') && request('recovery') == 'true') {
            $data = Lifting::onlyTrashed()->findOrFail($id);
            foreach ($data->products as $item) {
                LiftingReturnList::onlyTrashed()->where('lifting_product_id', $item->id)->restore();
            }
            AccountTransactionAuto::onlyTrashed()->where('voucher_no', $data->lifting_no)->where('voucher_type', 'Product Purchase')->restore();

            $payment = VendorPayment::onlyTrashed()->where('lifting_id', $id)->where('remarks', 'Cash Purchase')->first();
            if ($payment) {
                AccountTransactionAuto::onlyTrashed()->where('voucher_no', $payment->payment_no)->where('voucher_type', 'Vendor Payment')->restore();
                $payment->restore();
            }
            $data->restore();
            return response()->json(['status' => 'success']);
        }

        // Delete Multiple Items Permanent
        if (request()->has('id') && request()->has('parmanent') && request('parmanent') == 'true') {
            foreach (request('id') as $id) {
                $data = Lifting::onlyTrashed()->findOrFail($id);
                foreach ($data->products as $item) {
                    LiftingReturnList::where('lifting_product_id', $item->id)->forceDelete();
                }
                AccountTransactionAuto::onlyTrashed()->where('voucher_no', $data->lifting_no)->where('voucher_type', 'Product Purchase')->forceDelete();
                $payment = VendorPayment::onlyTrashed()->where('lifting_id', $id)->where('remarks', 'Cash Purchase')->first();
                if ($payment) {
                    AccountTransactionAuto::onlyTrashed()->where('voucher_no', $payment->payment_no)->where('voucher_type', 'Vendor Payment')->forceDelete();
                    $payment->forceDelete();
                }
                $data->forceDelete();
            }
            return response()->json(['status' => 'success']);
        }

        // Delete Single Item Permanent
        if (request()->has('parmanent') && request('parmanent') == 'true') {
            $data = Lifting::onlyTrashed()->findOrFail($id);
            foreach ($data->products as $item) {
                LiftingReturnList::where('lifting_product_id', $item->id)->forceDelete();
            }
            AccountTransactionAuto::onlyTrashed()->where('voucher_no', $data->lifting_no)->where('voucher_type', 'Product Purchase')->forceDelete();
            $payment = VendorPayment::onlyTrashed()->where('lifting_id', $id)->where('remarks', 'Cash Purchase')->first();
            if ($payment) {
                AccountTransactionAuto::onlyTrashed()->where('voucher_no', $payment->payment_no)->where('voucher_type', 'Vendor Payment')->forceDelete();
                $payment->forceDelete();
            }
            $data->forceDelete();
            return response()->json(['status' => 'success']);
        }

        // Delete Multiple Items
        if (request()->has('id')) {
            foreach (request('id') as $id) {
                $data = Lifting::findOrFail($id);
                foreach ($data->products as $item) {
                    LiftingReturnList::where('lifting_product_id', $item->id)->delete();
                }
                AccountTransactionAuto::where('voucher_no', $data->lifting_no)->where('voucher_type', 'Product Purchase')->delete();
                $payment = VendorPayment::where('lifting_id', $id)->where('remarks', 'Cash Purchase')->first();

                AccessLog::create([
                    'date_time' => Carbon::now(),
                    'page' => 'Purchase',
                    'action' => 'Delete',
                    'description' => 'Purchase delete against purchase no ' . $data->lifting_no . (!is_null($payment) ? ' payment delete ' . $payment->payment_no  : ''),
                    'user_id' => Auth::user()->id,
                ]);

                if ($payment) {
                    AccountTransactionAuto::where('voucher_no', $payment->payment_no)->where('voucher_type', 'Vendor Payment')->delete();
                    $payment->update(['deleted_by' => Auth::user()->id]);
                    $payment->delete();
                }
                $data->update(['deleted_by' => Auth::user()->id]);
                $data->delete();
            }
            return response()->json(['status' => 'success']);
        }

        // Delete Single Item
        $data = Lifting::findOrFail($id);
        foreach ($data->products as $item) {
            LiftingReturnList::where('lifting_product_id', $item->id)->delete();
        }
        AccountTransactionAuto::where('voucher_no', $data->lifting_no)->where('voucher_type', 'Product Purchase')->delete();
        $payment = VendorPayment::where('lifting_id', $id)->where('remarks', 'Cash Purchase')->first();

        AccessLog::create([
            'date_time' => Carbon::now(),
            'page' => 'Purchase',
            'action' => 'Delete',
            'description' => 'Purchase delete against purchase no ' . $data->lifting_no . (!is_null($payment) ? ' payment delete ' . $payment->payment_no  : ''),
            'user_id' => Auth::user()->id,
        ]);

        if ($payment) {
            AccountTransactionAuto::where('voucher_no', $payment->payment_no)->where('voucher_type', 'Vendor Payment')->delete();
            $payment->update(['deleted_by' => Auth::user()->id]);
            $payment->delete();
        }
        $data->update(['deleted_by' => Auth::user()->id]);
        $data->delete();

        return response()->json(['status' => 'success']);
    }
}
